from django.conf.urls import url, include
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^blog/', include('blog.urls' )),
    url(r'^account/', include('account.urls')),
    url(r'^article/', include('article.urls')),
]
